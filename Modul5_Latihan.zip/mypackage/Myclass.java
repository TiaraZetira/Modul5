// package mypackage

// public Myclass(){

// public static void sayHello() {
//     Myclass.sayHello(); 
// }

// }

