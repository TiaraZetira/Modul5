//package mypackage.Myclass;
//import Enkapsulasi.Car;


//public class Main {
   // public static void main(String[] args)   {
        // Myclass.sayHello();

     //Car myCar = new Car();
        //System.out.println(myCar.merk);
       // System.out.println(myCar.kapasistas);
        //System.out.println(myCar.jumlahBan);
  //  }

//}
