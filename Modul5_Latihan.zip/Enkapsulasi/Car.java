package Enkapsulasi;

public class Car {
    String pemilik;
    private String merk;
    public int kapasistas;
    protected int jumlahBan;
    
}
