package Enkapsulasi;

public class Main {
    public static void main(String[] args) {
        Mahasiswa mhs1 = new Mahasiswa();
        //System.out.println(mhs1.nama);
        System.out.println(mhs1.getNama());
        mhs1.setNama("Rian");
        System.out.println(mhs1.getNama());

        mhs1.setUmur(-20);
        //System.out.println(mhs1.getUmur());

        Car mycar1 = new Car ();
        System.out.println(mycar1.pemilik);
        System.out.println(mycar1.jumlahBan);
    }
}
