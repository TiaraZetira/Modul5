package Enkapsulasi;

public class Mahasiswa {
    private String nama = "Guardrian";
    private int umur;
    private String jurusan;

    //setter
    public void setNama(String nama) {
        this.nama = nama;
    }

    //getter
    public String getNama() {
        return nama;
    }

    public void setUmur(int umur) {
        if(umur >= 0){
            this.umur = umur;
        }else {
            System.out.println("Umur Tidak Valid");
        }
    }

    public int getUmur() {
        return umur;
    }
    
    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }

    public String getJurusan() {
        return jurusan;
    }
}
