
public class Main {
    public static void main (String[] args) 
    {
    Mahasiswa mhs1 = new Mahasiswa();
    ///mhs1.nama error
    mhs1.tampilkanInfo();
    System.out.println (mhs1.nama);
    System.out.println(mhs1.umur);

    Mahasiswa mhs2 = new Mahasiswa ("Rian");
    System.out.println(mhs2.nama);

    System.out.println((Mahasiswa.universitas));
    //System.out.println (Mahasiswa.nama);

    mhs1.sayHello("Harahap");
    System.out.println (mhs1.sayHello3("Khalil", 49, false));


    }
   
}