
public class Mahasiswa {
    
    //variabel instances
    String nama = "Rian";
    int umur = 20;

    //variabel static
    static String universitas = "Universitas Pertamina";

    public Mahasiswa() {
    }

    public Mahasiswa (String nama) {
        this.nama = nama;
        
    }
    public void tampilkanInfo() {
        //variabel Lokal
        String nama = "Rian";
        System.out.println(Mahasiswa.universitas);
        System.out.println(nama);
    }

    public void sayHello(String nama){
        System.out.println("Nama :" + nama);
        System.out.println("Nama :" + this.nama);
    }

    // public void sayHello2 (this.nama){
    //     System.out.println("Nama :" + nama);
    //     System.out.println("Nama :" + this.nama);
    // }

    //String nama2 = "Aiman";

    public String sayHello3 (String nama , int umur, boolean isLulus) {
      return "Nama Saya: " + nama + "\n" + "Umur Saya:" + umur + "\n" +"Boolean: " + isLulus + "\n";
    }

}
    