package arrayobject;
import Enkapsulasi.Mahasiswa;

public class Main {
    public static void main(String[] args) {

    //     Mahasiswa[] students = {
    //         new Mahasiswa("Rian" , 20 , 70 , 175),
    //         new Mahasiswa("Harahap" , 20 , 70 , 175),
    //     };

    //     for(Enkapsulasi.Mahasiswa mahasiswa : students) {
    //         System.out.println(mahasiswa.getNama());
    //     }

        //student [0];
        //student [1];
        //student [2];

        Mahasiswa[] mhs = new Mahasiswa[3];
        mhs[0] = new Mahasiswa();
        mhs[0].setNama("Rian");
        mhs[1].setNama("Harahap");

        for(Enkapsulasi.Mahasiswa mahasiswa : mhs) {
            System.out.println(mahasiswa.getNama());
            }

    }
}
